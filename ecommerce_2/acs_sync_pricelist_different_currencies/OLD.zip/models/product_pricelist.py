# -*- coding: utf-8 -*-
# Copyright 2024 Juan Ayala - A&C Sistemas
# License LGPL-3.0 or later (http://www.gnu.org/licenses/lgpl).

from odoo import models, fields, api
from odoo.exceptions import UserError
import logging
from datetime import timedelta

_logger = logging.getLogger(__name__)


class ProductPricelist(models.Model):
    _inherit = 'product.pricelist'

    # Campo para relacionar las listas de precios
    linked_pricelist_id = fields.Many2one(
        'product.pricelist',
        string='Lista de Precios Vinculada',
        help='Lista de precios que se sincronizará automáticamente con esta'
    )

    # Campo para indicar si es la lista principal (la que controla los cambios)
    is_master_pricelist = fields.Boolean(
        string='Lista Principal',
        default=False,
        help='Si está marcado, los cambios en esta lista se propagarán a la lista vinculada'
    )

    # Campo para almacenar la última tasa de cambio usada
    last_currency_rate = fields.Float(
        string='Última Tasa de Cambio',
        digits=(12, 6),
        help='Última tasa de cambio utilizada para la sincronización'
    )

    # Campo para la fecha de última actualización
    last_update_date = fields.Datetime(
        string='Última Actualización',
        help='Fecha y hora de la última sincronización de precios'
    )

    # Campo para habilitar actualización automática por tipo de cambio
    auto_update_currency = fields.Boolean(
        string='Actualización Automática por Tipo de Cambio',
        default=True,
        help='Si está marcado, los precios se actualizarán automáticamente cuando cambie el tipo de cambio'
    )

    @api.constrains('linked_pricelist_id', 'is_master_pricelist')
    def _check_linked_pricelist(self):
        for pricelist in self:
            if pricelist.linked_pricelist_id and pricelist.linked_pricelist_id.id == pricelist.id:
                raise UserError(
                    "Una lista de precios no puede estar vinculada consigo misma.")

            if pricelist.is_master_pricelist and pricelist.linked_pricelist_id:
                if pricelist.linked_pricelist_id.is_master_pricelist:
                    raise UserError(
                        "No pueden existir dos listas principales vinculadas entre sí.")

    def update_prices_by_currency_rate(self):
        """CASO 2: Actualiza los precios de listas vinculadas cuando cambia el tipo de cambio"""
        master_pricelists = self.search([
            ('is_master_pricelist', '=', True),
            ('linked_pricelist_id', '!=', False),
            ('auto_update_currency', '=', True)
        ])

        updated_count = 0

        for pricelist in master_pricelists:
            try:
                current_rate = pricelist._get_current_currency_rate()

                # Actualizar SIEMPRE si hay diferencia (sin importar qué tan pequeña)
                # Esto asegura que cualquier cambio en TC se refleje
                if current_rate != (pricelist.last_currency_rate or 0):
                    _logger.info(f"CASO 2 - Actualizando precios para {pricelist.name}. "
                                 f"Tasa anterior: {pricelist.last_currency_rate}, "
                                 f"Tasa actual: {current_rate}")

                    items_updated = pricelist._update_linked_prices_by_rate(
                        current_rate)
                    pricelist.write({
                        'last_currency_rate': current_rate,
                        'last_update_date': fields.Datetime.now()
                    })
                    updated_count += items_updated

                    _logger.info(
                        f"CASO 2 - Actualizados {items_updated} items en {pricelist.linked_pricelist_id.name}")

            except Exception as e:
                _logger.error(
                    f"Error actualizando precios para {pricelist.name}: {str(e)}")
                continue

        if updated_count > 0:
            _logger.info(
                f"CASO 2 - Total de items actualizados por cambio de TC: {updated_count}")

        return updated_count

    def _get_current_currency_rate(self):
        """Obtiene la tasa de cambio actual"""
        if not self.linked_pricelist_id:
            return 1.0

        return self.currency_id._get_conversion_rate(
            self.currency_id,
            self.linked_pricelist_id.currency_id,
            self.env.company,
            fields.Date.today()
        )

    def _update_linked_prices_by_rate(self, new_rate):
        """CASO 2: Actualiza todos los precios de la lista vinculada con la nueva tasa"""
        if not self.linked_pricelist_id:
            return 0

        # Obtener todos los items de la lista principal
        master_items = self.env['product.pricelist.item'].search([
            ('pricelist_id', '=', self.id)
        ])

        updated_items = 0

        for master_item in master_items:
            # Buscar el item correspondiente en la lista vinculada
            linked_item = master_item._find_existing_linked_item(
                master_item, self.linked_pricelist_id)

            if linked_item and master_item.fixed_price > 0:
                old_price = linked_item.fixed_price
                new_price = master_item.fixed_price * new_rate

                # Solo actualizar si hay diferencia real
                if abs(old_price - new_price) > 0.01:  # diferencia mínima de 1 centavo
                    linked_item.with_context(skip_sync=True).write({
                        'fixed_price': new_price
                    })
                    updated_items += 1

                    product_name = master_item.product_id.name or master_item.product_tmpl_id.name
                    _logger.debug(f"CASO 2 - Actualizado {product_name}: {old_price} -> {new_price} "
                                  f"(USD: {master_item.fixed_price} × TC: {new_rate})")

        return updated_items

    def action_update_currency_rates(self):
        """Acción para actualizar manualmente los precios por tipo de cambio"""
        if self.is_master_pricelist and self.linked_pricelist_id:
            updated_items = self.update_prices_by_currency_rate()
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': 'Actualización Completada',
                    'message': f'Se actualizaron {updated_items} items en {self.linked_pricelist_id.name}.',
                    'type': 'success' if updated_items > 0 else 'info',
                }
            }
        else:
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': 'Sin Cambios',
                    'message': 'Esta lista no tiene una lista vinculada o no es la lista principal.',
                    'type': 'warning',
                }
            }


class ProductPricelistItem(models.Model):
    _inherit = 'product.pricelist.item'

    @api.model_create_multi
    def create(self, vals_list):
        items = super().create(vals_list)

        for item in items:
            self._sync_pricelist_item(item, 'create')

        return items

    def write(self, vals):
        result = super().write(vals)

        # CASO 1: Solo sincronizar si se modifican campos relevantes de precios
        sync_fields = ['fixed_price', 'percent_price', 'price_discount', 'min_quantity',
                       'date_start', 'date_end', 'product_tmpl_id', 'product_id']

        if any(field in vals for field in sync_fields):
            for item in self:
                # Agregar logging para CASO 1
                if 'fixed_price' in vals:
                    _logger.info(f"CASO 1 - Cambio manual de precio: {item.product_id.name or item.product_tmpl_id.name} "
                                 f"nuevo precio: {vals.get('fixed_price')}")

                self._sync_pricelist_item(item, 'write', vals)

        return result

    def unlink(self):
        # Antes de eliminar, sincronizar la eliminación
        for item in self:
            self._sync_pricelist_item(item, 'unlink')

        return super().unlink()

    def _sync_pricelist_item(self, item, operation, vals=None):
        """Sincroniza un item de lista de precios con su lista vinculada"""
        pricelist = item.pricelist_id

        # Solo procesar si esta lista es la principal y tiene una vinculada
        if not pricelist.is_master_pricelist or not pricelist.linked_pricelist_id:
            return

        linked_pricelist = pricelist.linked_pricelist_id

        # CASO 1: Obtener tipo de cambio ACTUAL (no almacenado)
        # Esto asegura que siempre use la tasa más reciente
        rate = self._get_currency_rate(
            pricelist.currency_id, linked_pricelist.currency_id)

        # Actualizar la tasa almacenada en la lista principal
        if abs(rate - (pricelist.last_currency_rate or 0)) > 0.001:
            pricelist.with_context(skip_sync=True).write({
                'last_currency_rate': rate,
                'last_update_date': fields.Datetime.now()
            })

        if operation == 'create':
            self._create_linked_item(item, linked_pricelist, rate)
        elif operation == 'write':
            self._update_linked_item(item, linked_pricelist, rate, vals)
        elif operation == 'unlink':
            self._delete_linked_item(item, linked_pricelist)

    def _get_currency_rate(self, from_currency, to_currency):
        """Obtiene el tipo de cambio entre dos monedas"""
        if from_currency == to_currency:
            return 1.0

        # Usar el tipo de cambio actual
        rate = from_currency._get_conversion_rate(
            from_currency,
            to_currency,
            self.env.company,
            fields.Date.today()
        )

        return rate

    def _create_linked_item(self, item, linked_pricelist, rate):
        """Crea un item en la lista de precios vinculada"""
        vals = self._prepare_linked_item_vals(item, linked_pricelist, rate)

        # Verificar si ya existe un item similar
        existing_item = self._find_existing_linked_item(item, linked_pricelist)
        if existing_item:
            existing_item.with_context(skip_sync=True).write(vals)
        else:
            self.with_context(skip_sync=True).create(vals)

    def _update_linked_item(self, item, linked_pricelist, rate, vals):
        """Actualiza un item en la lista de precios vinculada"""
        existing_item = self._find_existing_linked_item(item, linked_pricelist)

        if existing_item:
            update_vals = {}

            # Solo actualizar campos que cambiaron (excepto precios que se convierten)
            if 'fixed_price' in vals:
                update_vals['fixed_price'] = vals['fixed_price'] * \
                    rate if vals['fixed_price'] else 0

            if 'percent_price' in vals:
                update_vals['percent_price'] = vals['percent_price']

            if 'price_discount' in vals:
                update_vals['price_discount'] = vals['price_discount']

            if 'min_quantity' in vals:
                update_vals['min_quantity'] = vals['min_quantity']

            if 'date_start' in vals:
                update_vals['date_start'] = vals['date_start']

            if 'date_end' in vals:
                update_vals['date_end'] = vals['date_end']

            if update_vals:
                existing_item.with_context(skip_sync=True).write(update_vals)
        else:
            # Si no existe, crear uno nuevo
            self._create_linked_item(item, linked_pricelist, rate)

    def _delete_linked_item(self, item, linked_pricelist):
        """Elimina el item correspondiente en la lista de precios vinculada"""
        existing_item = self._find_existing_linked_item(item, linked_pricelist)
        if existing_item:
            existing_item.with_context(skip_sync=True).unlink()

    def _find_existing_linked_item(self, item, linked_pricelist):
        """Busca si ya existe un item similar en la lista vinculada"""
        domain = [
            ('pricelist_id', '=', linked_pricelist.id),
        ]

        if item.product_tmpl_id:
            domain.append(('product_tmpl_id', '=', item.product_tmpl_id.id))

        if item.product_id:
            domain.append(('product_id', '=', item.product_id.id))

        domain.extend([
            ('min_quantity', '=', item.min_quantity),
            ('date_start', '=', item.date_start),
            ('date_end', '=', item.date_end),
        ])

        return self.search(domain, limit=1)

    def _prepare_linked_item_vals(self, item, linked_pricelist, rate):
        """Prepara los valores para crear/actualizar un item vinculado"""
        vals = {
            'pricelist_id': linked_pricelist.id,
            'product_tmpl_id': item.product_tmpl_id.id if item.product_tmpl_id else False,
            'product_id': item.product_id.id if item.product_id else False,
            'categ_id': item.categ_id.id if item.categ_id else False,
            'min_quantity': item.min_quantity,
            'date_start': item.date_start,
            'date_end': item.date_end,
            'compute_price': item.compute_price,
            'percent_price': item.percent_price,
            'price_discount': item.price_discount,
        }

        # Convertir precio fijo si existe
        if item.fixed_price:
            vals['fixed_price'] = item.fixed_price * rate
        else:
            vals['fixed_price'] = 0

        return vals

    def create(self, vals_list):
        # Evitar sincronización recursiva
        if self.env.context.get('skip_sync'):
            return super(ProductPricelistItem, self).create(vals_list)

        return super().create(vals_list)

    def write(self, vals):
        # Evitar sincronización recursiva
        if self.env.context.get('skip_sync'):
            return super(ProductPricelistItem, self).write(vals)

        return super().write(vals)


# Extender el modelo de moneda para detectar cambios
class ResCurrency(models.Model):
    _inherit = 'res.currency'

    def write(self, vals):
        result = super().write(vals)

        # Si se modifican las tasas de cambio, actualizar precios inmediatamente
        if 'rate' in vals:
            self._trigger_pricelist_update()

        return result

    def _trigger_pricelist_update(self):
        """CASO 2: Dispara la actualización de listas de precios por cambio de TC"""
        try:
            _logger.info(
                "CASO 2 - Detectado cambio en tipo de cambio de moneda")
            updated_items = self.env['product.pricelist'].sudo(
            ).update_prices_by_currency_rate()
            _logger.info(
                f"CASO 2 - Finalizada actualización por cambio de TC. Items actualizados: {updated_items}")
        except Exception as e:
            _logger.error(
                f"CASO 2 - Error actualizando precios por cambio de moneda: {str(e)}")


class ResCurrencyRate(models.Model):
    _inherit = 'res.currency.rate'

    @api.model_create_multi
    def create(self, vals_list):
        result = super().create(vals_list)

        # CASO 2: Actualizar precios cuando se crean nuevas tasas
        _logger.info(
            f"CASO 2 - Creadas nuevas tasas de cambio: {len(vals_list)} registros")
        self._trigger_pricelist_update()

        return result

    def write(self, vals):
        result = super().write(vals)

        # CASO 2: Actualizar precios cuando se modifican tasas
        if 'rate' in vals:
            _logger.info(
                f"CASO 2 - Modificada tasa de cambio. Nueva tasa: {vals['rate']}")
            self._trigger_pricelist_update()

        return result

    def _trigger_pricelist_update(self):
        """CASO 2: Dispara la actualización de listas de precios por cambio de TC"""
        try:
            _logger.info("CASO 2 - Detectado cambio en tasa de cambio")
            updated_items = self.env['product.pricelist'].sudo(
            ).update_prices_by_currency_rate()
            _logger.info(
                f"CASO 2 - Finalizada actualización por cambio de TC. Items actualizados: {updated_items}")
        except Exception as e:
            _logger.error(
                f"CASO 2 - Error actualizando precios por cambio de tasa: {str(e)}")
