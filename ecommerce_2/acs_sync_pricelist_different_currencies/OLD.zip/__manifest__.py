# -*- coding: utf-8 -*-
{
    'name': 'ACS - Sincronización de Listas de Precios por Moneda',
    'version': '18.0.1.0.0',
    'category': 'Sales',
    'summary': 'Sincroniza automáticamente listas de precios entre diferentes monedas',
    'description': """
ACS - Sincronización de Listas de Precios por Moneda
====================================================

Este módulo permite mantener sincronizadas dos listas de precios con diferentes monedas,
aplicando automáticamente el tipo de cambio cuando se modifican los precios o cuando
cambia la tasa de conversión.

Características principales:
---------------------------
* Sincronización automática al cambiar precios manualmente
* Actualización automática cuando cambia el tipo de cambio
* Configuración de lista principal y secundaria
* Asistente de configuración fácil de usar
* Tarea programada para verificación periódica
* Logs detallados para seguimiento
* Botones de actualización manual

Casos de uso:
-------------
1. Lista de precios en USD (principal) → Lista de precios en PEN (secundaria)
2. Productos con precios base en dólares que se venden ocasionalmente en soles
3. Actualización automática por fluctuaciones del tipo de cambio

Autor: Juan Ayala - A&C Sistemas
Web: www.acsistemasperu.com
""",
    'author': 'Juan Ayala - A&C Sistemas',
    'website': 'https://www.acsistemasperu.com',
    'license': 'LGPL-3',
    'depends': ['sale', 'product'],
    'data': [
        'security/ir.model.access.csv',
        'data/ir_cron.xml',
        'views/product_pricelist_views.xml',
        'wizard/pricelist_sync_wizard_views.xml',
    ],
    'images': ['static/description/icon.png'],
    'installable': True,
    'auto_install': False,
    'application': False,
}
