# -*- coding: utf-8 -*-
# Copyright 2024 Juan Ayala - A&C Sistemas
# License LGPL-3.0 or later (http://www.gnu.org/licenses/lgpl).

from odoo import models, fields, api
from odoo.exceptions import UserError


class PricelistSyncWizard(models.TransientModel):
    _name = 'pricelist.sync.wizard'
    _description = 'Asistente para Configurar Sincronización de Listas de Precios'

    master_pricelist_id = fields.Many2one(
        'product.pricelist',
        string='Lista de Precios Principal (USD)',
        required=True,
        help='Esta será la lista que controle los cambios'
    )

    slave_pricelist_id = fields.Many2one(
        'product.pricelist',
        string='Lista de Precios Secundaria (PEN)',
        required=True,
        help='Esta lista se actualizará automáticamente'
    )

    sync_existing_items = fields.Boolean(
        string='Sincronizar Items Existentes',
        default=True,
        help='Si está marcado, copiará todos los items existentes de la lista principal a la secundaria'
    )

    @api.constrains('master_pricelist_id', 'slave_pricelist_id')
    def _check_pricelists(self):
        for wizard in self:
            if wizard.master_pricelist_id.id == wizard.slave_pricelist_id.id:
                raise UserError(
                    "La lista principal y secundaria no pueden ser la misma.")

            if wizard.master_pricelist_id.currency_id == wizard.slave_pricelist_id.currency_id:
                raise UserError(
                    "Las listas de precios deben tener monedas diferentes.")

    def action_configure_sync(self):
        """Configura la sincronización entre las listas de precios"""
        self.ensure_one()

        # Configurar la lista principal
        self.master_pricelist_id.write({
            'is_master_pricelist': True,
            'linked_pricelist_id': self.slave_pricelist_id.id
        })

        # Configurar la lista secundaria
        self.slave_pricelist_id.write({
            'is_master_pricelist': False,
            'linked_pricelist_id': self.master_pricelist_id.id
        })

        # Sincronizar items existentes si se solicita
        if self.sync_existing_items:
            self._sync_existing_items()

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Configuración Exitosa',
                'message': f'Las listas de precios han sido vinculadas correctamente.',
                'type': 'success',
            }
        }

    def _sync_existing_items(self):
        """Sincroniza todos los items existentes de la lista principal a la secundaria"""
        master_items = self.env['product.pricelist.item'].search([
            ('pricelist_id', '=', self.master_pricelist_id.id)
        ])

        # Obtener tipo de cambio
        rate = master_items._get_currency_rate(
            self.master_pricelist_id.currency_id,
            self.slave_pricelist_id.currency_id
        )

        # Crear items en la lista secundaria
        for item in master_items:
            # Verificar si ya existe
            existing = item._find_existing_linked_item(
                item, self.slave_pricelist_id)
            if not existing:
                vals = item._prepare_linked_item_vals(
                    item, self.slave_pricelist_id, rate)
                self.env['product.pricelist.item'].with_context(
                    skip_sync=True).create(vals)
