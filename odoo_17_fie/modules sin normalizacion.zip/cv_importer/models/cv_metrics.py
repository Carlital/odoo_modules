from odoo import models, fields, api
from datetime import datetime, timedelta
import time
import logging

_logger = logging.getLogger(__name__)

class CvMetrics(models.Model):
    _name = 'cv.metrics'
    _description = 'CV Import Metrics'
    _order = 'create_date desc'
    
    operation_type = fields.Selection([
        ('import', 'Import CV'),
        ('parse', 'Parse CV'),
        ('validate', 'Validate CV'),
        ('cache_hit', 'Cache Hit'),
        ('cache_miss', 'Cache Miss'),
        ('error', 'Error')
    ], required=True)
    
    execution_time = fields.Float('Execution Time (seconds)', digits=(10, 4))
    file_size = fields.Integer('File Size (bytes)')
    success = fields.Boolean('Success', default=True)
    error_message = fields.Text('Error Message')
    employee_id = fields.Many2one('hr.employee', 'Candidate')

    import_time = fields.Float('Tiempo de Importación (s)')
    error_count = fields.Integer('Errores')
    cache_hits = fields.Integer('Aciertos de Caché')
    cache_misses = fields.Integer('Fallos de Caché')
    imported_at = fields.Datetime('Fecha de Importación', default=fields.Datetime.now)
    user_id = fields.Many2one('res.users', 'Usuario')
    
    @api.model
    def record_import_metric(        
        self,
        start_time=None,
        file_size=0,
        success=True,
        error_msg=None,
        employee_id=None,
        operation_type='import',
        duration_seconds=None,
        user_id=None,
    ):
        """
        Helper para crear un registro de métricas desde el callback/subida.
        Devuelve el record creado (recordset) o False en caso de fallo.
        Se adapta dinámicamente a los campos definidos en el modelo para evitar excepciones.
        """
        try:
            vals = {}
            # operation_type es required en el modelo
            vals['operation_type'] = operation_type or 'import'

            if 'file_size' in self._fields:
                try:
                    vals['file_size'] = int(file_size or 0)
                except Exception:
                    vals['file_size'] = 0
            if 'success' in self._fields:
                vals['success'] = bool(success)
            if 'error_message' in self._fields:
                vals['error_message'] = error_msg or False
            # campo correcto en el modelo: cv_candidate_id
            if 'employee_id' in self._fields and employee_id:
                vals['employee_id'] = employee_id.id if hasattr(employee_id, 'id') else employee_id

            computed_duration = None
            try:
                if duration_seconds is not None:
                    computed_duration = float(duration_seconds)
                elif start_time is not None:
                    import time as _time
                    st = float(start_time)
                    computed_duration = float(_time.time() - st)
            except Exception:
                computed_duration = None

            if computed_duration is not None:
                if 'execution_time' in self._fields:
                    try:
                        vals['execution_time'] = float(computed_duration)
                    except Exception:
                        pass
                if 'import_time' in self._fields:
                    try:
                        vals['import_time'] = float(computed_duration)
                    except Exception:
                        pass
            else:
                # si no se pudo calcular duration y se pasó duration_seconds, intentar asignar
                if duration_seconds is not None and 'execution_time' in self._fields:
                    try:
                        vals['execution_time'] = float(duration_seconds)
                    except Exception:
                        pass


            if 'user_id' in self._fields and user_id:
                vals['user_id'] = user_id.id if hasattr(user_id, 'id') else user_id
            
            rec = self.sudo().create(vals)

            # Si nos dan start_time, intentar setear imported_at
            if start_time and 'imported_at' in self._fields:
                try:
                    from datetime import datetime, timezone
                    if isinstance(start_time, (int, float)):
                        dt = datetime.fromtimestamp(float(start_time), timezone.utc)
                    else:
                        dt = datetime.fromisoformat(str(start_time))
                    rec.write({'imported_at': dt.strftime('%Y-%m-%d %H:%M:%S')})
                except Exception:
                    pass

            _logger.info(
                "cv.metrics creado id=%s operation_type=%s file_size=%s success=%s",
                getattr(rec, 'id', False),
                vals.get('operation_type'),
                vals.get('file_size'),
                vals.get('success'),
            )
            return rec
        except Exception:
            _logger.exception("Error creando métrica en record_import_metric")
            return False

    @api.model
    def record_cache_metric(self, cache_hit=True):
        """Registra métricas de caché"""
        try:
            self.sudo().create({
                'operation_type': 'cache_hit' if cache_hit else 'cache_miss',
                'execution_time': 0,
                'success': True
            })
        except Exception:
            _logger.exception("Error creando métrica de caché")
    
    @api.model
    def record_cache_metric(self, cache_hit=True):
        """Registra métricas de caché"""
        self.create({
            'operation_type': 'cache_hit' if cache_hit else 'cache_miss',
            'execution_time': 0,
            'success': True
        })
    
    @api.model
    def get_performance_report(self, days=7):
        """Genera reporte de rendimiento"""
        domain = [('create_date', '>=', datetime.now() - timedelta(days=days))]
        metrics = self.search(domain)
        
        if not metrics:
            return {'error': 'No metrics found'}
        
        # Métricas de tiempo
        import_metrics = metrics.filtered(lambda m: m.operation_type == 'import')
        avg_import_time = sum(import_metrics.mapped('execution_time')) / len(import_metrics) if import_metrics else 0
        
        # Métricas de errores
        error_metrics = metrics.filtered(lambda m: m.operation_type == 'error')
        error_rate = (len(error_metrics) / len(metrics)) * 100 if metrics else 0
        
        # Métricas de caché
        cache_hits = metrics.filtered(lambda m: m.operation_type == 'cache_hit')
        cache_misses = metrics.filtered(lambda m: m.operation_type == 'cache_miss')
        cache_hit_rate = (len(cache_hits) / (len(cache_hits) + len(cache_misses))) * 100 if (cache_hits or cache_misses) else 0
        
        return {
            'total_operations': len(metrics),
            'avg_import_time': round(avg_import_time, 2),
            'error_rate': round(error_rate, 2),
            'cache_hit_rate': round(cache_hit_rate, 2),
            'total_errors': len(error_metrics),
            'period_days': days
        }
