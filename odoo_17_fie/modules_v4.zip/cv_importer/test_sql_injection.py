#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script de prueba para SQL Injection Testing
============================================
Usa este script para probar los endpoints desde línea de comandos.

Uso:
    python test_sql_injection.py
"""

import requests
import json

# Configuración
BASE_URL = "http://localhost:8069"
DATABASE = "tu_database"  # Cambiar por tu database
USERNAME = "admin"        # Cambiar por tu usuario
PASSWORD = "admin"        # Cambiar por tu contraseña

# Colores para terminal
class Colors:
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    END = '\033[0m'


def print_header(text):
    """Imprime un header destacado"""
    print(f"\n{Colors.BOLD}{Colors.CYAN}{'='*80}{Colors.END}")
    print(f"{Colors.BOLD}{Colors.CYAN}{text.center(80)}{Colors.END}")
    print(f"{Colors.BOLD}{Colors.CYAN}{'='*80}{Colors.END}\n")


def print_test(name, payload, vulnerable=False):
    """Imprime información de la prueba"""
    color = Colors.RED if vulnerable else Colors.GREEN
    marker = "❌ VULNERABLE" if vulnerable else "✅ SEGURO"
    print(f"{Colors.BOLD}{color}{marker}{Colors.END}")
    print(f"{Colors.BOLD}Prueba:{Colors.END} {name}")
    print(f"{Colors.BOLD}Payload:{Colors.END} {Colors.YELLOW}{payload}{Colors.END}")
    print()


def authenticate():
    """Autentica y obtiene session_id"""
    print_header("AUTENTICACIÓN")
    
    url = f"{BASE_URL}/web/session/authenticate"
    payload = {
        "jsonrpc": "2.0",
        "method": "call",
        "params": {
            "db": DATABASE,
            "login": USERNAME,
            "password": PASSWORD
        },
        "id": 1
    }
    
    session = requests.Session()
    response = session.post(url, json=payload)
    
    if response.status_code == 200:
        result = response.json().get('result', {})
        if result.get('uid'):
            print(f"{Colors.GREEN}✓ Autenticación exitosa{Colors.END}")
            print(f"User ID: {result['uid']}")
            return session
        else:
            print(f"{Colors.RED}✗ Error de autenticación{Colors.END}")
            print(result)
            return None
    else:
        print(f"{Colors.RED}✗ Error HTTP: {response.status_code}{Colors.END}")
        return None


def test_endpoint(session, endpoint, search_term, test_name, vulnerable=False):
    """Prueba un endpoint específico"""
    print_test(test_name, search_term, vulnerable)
    
    url = f"{BASE_URL}{endpoint}"
    payload = {
        "jsonrpc": "2.0",
        "method": "call",
        "params": {
            "search_term": search_term
        },
        "id": 1
    }
    
    try:
        response = session.post(url, json=payload)
        
        if response.status_code == 200:
            result = response.json().get('result', {})
            
            if result.get('success'):
                print(f"{Colors.GREEN}✓ Respuesta exitosa{Colors.END}")
                print(f"{Colors.BOLD}Método:{Colors.END} {result.get('method', 'N/A')}")
                
                if 'query_executed' in result:
                    print(f"{Colors.BOLD}Query ejecutada:{Colors.END}")
                    print(f"{Colors.YELLOW}{result['query_executed']}{Colors.END}")
                
                results = result.get('results', [])
                print(f"{Colors.BOLD}Registros retornados:{Colors.END} {len(results)}")
                
                if results:
                    print(f"\n{Colors.BOLD}Primeros 3 resultados:{Colors.END}")
                    for i, record in enumerate(results[:3], 1):
                        print(f"  {i}. {record.get('name', 'N/A')} - {record.get('work_email', 'N/A')}")
            else:
                print(f"{Colors.RED}✗ Error en la consulta:{Colors.END}")
                print(result.get('error', 'Error desconocido'))
                
        else:
            print(f"{Colors.RED}✗ Error HTTP: {response.status_code}{Colors.END}")
            
    except Exception as e:
        print(f"{Colors.RED}✗ Excepción: {str(e)}{Colors.END}")
    
    print(f"{Colors.BLUE}{'-'*80}{Colors.END}\n")


def run_tests():
    """Ejecuta todas las pruebas"""
    print_header("SQL INJECTION TESTING LAB")
    print(f"{Colors.YELLOW}⚠️  Este script prueba código INTENCIONALMENTE VULNERABLE{Colors.END}")
    print(f"{Colors.YELLOW}⚠️  Solo para ambiente de desarrollo/testing{Colors.END}\n")
    
    # Autenticar
    session = authenticate()
    if not session:
        return
    
    # ========================================================================
    # PRUEBAS CON MÉTODO VULNERABLE
    # ========================================================================
    print_header("PRUEBAS CON MÉTODO VULNERABLE")
    
    # Prueba 1: Búsqueda normal
    test_endpoint(
        session, 
        "/cv_test/vulnerable_search",
        "Juan",
        "Búsqueda Normal",
        vulnerable=True
    )
    
    # Prueba 2: SQL Injection básica
    test_endpoint(
        session,
        "/cv_test/vulnerable_search",
        "' OR '1'='1",
        "SQL Injection - Bypass Simple",
        vulnerable=True
    )
    
    # Prueba 3: SQL Injection con comentario
    test_endpoint(
        session,
        "/cv_test/vulnerable_search",
        "' OR '1'='1' --",
        "SQL Injection - Con Comentario",
        vulnerable=True
    )
    
    # Prueba 4: UNION Attack (cuidado, puede fallar)
    test_endpoint(
        session,
        "/cv_test/vulnerable_search",
        "' UNION SELECT id, login, 'hacked', null FROM res_users WHERE '1'='1",
        "SQL Injection - UNION Attack",
        vulnerable=True
    )
    
    # ========================================================================
    # PRUEBAS CON MÉTODO SEGURO (PARÁMETROS)
    # ========================================================================
    print_header("PRUEBAS CON MÉTODO SEGURO (Parámetros SQL)")
    
    # Prueba 5: Búsqueda normal segura
    test_endpoint(
        session,
        "/cv_test/secure_search",
        "Juan",
        "Búsqueda Normal Segura",
        vulnerable=False
    )
    
    # Prueba 6: Intento de inyección - debería fallar
    test_endpoint(
        session,
        "/cv_test/secure_search",
        "' OR '1'='1",
        "Intento de SQL Injection Bloqueado",
        vulnerable=False
    )
    
    # ========================================================================
    # PRUEBAS CON ORM
    # ========================================================================
    print_header("PRUEBAS CON ORM DE ODOO")
    
    # Prueba 7: Búsqueda normal con ORM
    test_endpoint(
        session,
        "/cv_test/orm_search",
        "Juan",
        "Búsqueda Normal con ORM",
        vulnerable=False
    )
    
    # Prueba 8: Intento de inyección con ORM - debería fallar
    test_endpoint(
        session,
        "/cv_test/orm_search",
        "' OR '1'='1",
        "Intento de SQL Injection con ORM (Bloqueado)",
        vulnerable=False
    )
    
    # ========================================================================
    # RESUMEN
    # ========================================================================
    print_header("RESUMEN")
    print(f"{Colors.BOLD}Conclusiones:{Colors.END}\n")
    print(f"{Colors.RED}❌ Método Vulnerable:{Colors.END}")
    print("   - Permite inyección SQL exitosa")
    print("   - Puede exponer todos los registros")
    print("   - NUNCA usar en producción\n")
    
    print(f"{Colors.GREEN}✅ Método con Parámetros:{Colors.END}")
    print("   - Bloquea inyecciones SQL")
    print("   - Escapa automáticamente el input")
    print("   - Seguro pero requiere cuidado\n")
    
    print(f"{Colors.GREEN}✅✅ Método con ORM:{Colors.END}")
    print("   - El más seguro de todos")
    print("   - Abstracto y fácil de usar")
    print("   - SIEMPRE preferir este método\n")
    
    print(f"{Colors.CYAN}🎓 Tu código productivo está SEGURO{Colors.END}")
    print(f"{Colors.CYAN}   (usa ORM correctamente, sin SQL directo){Colors.END}\n")


if __name__ == "__main__":
    print(f"\n{Colors.BOLD}SQL Injection Testing Script{Colors.END}")
    print(f"{Colors.MAGENTA}{'─'*80}{Colors.END}\n")
    
    print(f"{Colors.YELLOW}Configuración actual:{Colors.END}")
    print(f"  URL: {BASE_URL}")
    print(f"  Database: {DATABASE}")
    print(f"  Usuario: {USERNAME}\n")
    
    response = input(f"{Colors.BOLD}¿Continuar con las pruebas? (s/n): {Colors.END}")
    
    if response.lower() in ['s', 'si', 'y', 'yes']:
        run_tests()
    else:
        print(f"\n{Colors.YELLOW}Pruebas canceladas{Colors.END}\n")
