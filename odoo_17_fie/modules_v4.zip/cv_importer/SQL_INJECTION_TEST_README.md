# 🔐 Laboratorio de Pruebas de Inyección SQL

## ⚠️ ADVERTENCIA IMPORTANTE

Este laboratorio contiene código **INTENCIONALMENTE VULNERABLE** para propósitos educativos y de pruebas de seguridad.

**NUNCA usar en producción.**

## 📋 Resumen de Auditoría

✅ **Estado del código productivo:** SEGURO
- ✅ No se encontraron consultas SQL directas en ningún módulo
- ✅ Todo el código usa el ORM de Odoo correctamente
- ✅ No hay vulnerabilidades de inyección SQL en producción

## 🎯 Propósito

Este laboratorio te permite:
1. Entender cómo funcionan las inyecciones SQL
2. Comparar código vulnerable vs seguro
3. Probar técnicas de ataque en un entorno controlado
4. Validar que tus defensas funcionan correctamente

## 🚀 Cómo Usar

### 1. Acceder al Laboratorio

Después de reiniciar Odoo, visita:
```
http://localhost:8069/cv_test/sql_injection_demo
```

### 2. Métodos Disponibles

#### ❌ Método Vulnerable (Concatenación Directa)
- **Endpoint:** `/cv_test/vulnerable_search`
- **Riesgo:** El input se concatena directamente en la query SQL
- **Usa para:** Probar técnicas de inyección

#### ✅ Método Seguro (Parámetros Parametrizados)
- **Endpoint:** `/cv_test/secure_search`
- **Protección:** Usa parámetros parametrizados (`%s`)
- **Usa para:** Ver cómo los parámetros previenen inyección

#### ✅✅ Método Más Seguro (ORM)
- **Endpoint:** `/cv_test/orm_search`
- **Protección:** Usa el ORM de Odoo
- **Usa para:** El método RECOMENDADO para producción

### 3. Ejemplos de Pruebas

#### Búsqueda Normal
```
Input: Juan
Resultado: Busca empleados con nombre "Juan"
```

#### Bypass de Autenticación
```
Input: ' OR '1'='1
Resultado Vulnerable: Retorna TODOS los empleados
Resultado Seguro: Busca literalmente el string "' OR '1'='1" (sin match)
```

#### Comentario SQL
```
Input: ' OR '1'='1' --
Resultado Vulnerable: Ejecuta la inyección y comenta el resto
Resultado Seguro: Escapa automáticamente
```

#### UNION Attack
```
Input: ' UNION SELECT id, login, password, null FROM res_users --
Resultado Vulnerable: Podría exponer datos de usuarios
Resultado Seguro: Falla o retorna vacío
```

## 🔧 Estructura del Código

### Código Vulnerable (SOLO PARA PRUEBAS)
```python
# ❌ NUNCA HACER ESTO
query = f"SELECT * FROM hr_employee WHERE name ILIKE '%{search_term}%'"
request.env.cr.execute(query)
```

### Código Seguro con SQL Directo
```python
# ✅ Si DEBES usar SQL directo, usa parámetros
query = "SELECT * FROM hr_employee WHERE name ILIKE %s"
request.env.cr.execute(query, (f'%{search_term}%',))
```

### Código Más Seguro con ORM
```python
# ✅✅ SIEMPRE preferir esto
employees = request.env['hr.employee'].search([
    ('name', 'ilike', search_term)
])
```

## 📊 Comparación de Métodos

| Método | Seguridad | Facilidad | Mantenibilidad | Recomendado |
|--------|-----------|-----------|----------------|-------------|
| Concatenación | ❌ Muy baja | ✅ Fácil | ❌ Difícil | ❌ NUNCA |
| Parámetros SQL | ✅ Alta | ⚠️ Media | ⚠️ Media | ⚠️ Solo si necesario |
| ORM Odoo | ✅✅ Muy alta | ✅ Muy fácil | ✅ Muy fácil | ✅ SIEMPRE |

## 🗑️ Cómo Eliminar Este Código de Prueba

Cuando termines las pruebas:

### Opción 1: Comentar (recomendado para mantener referencia)
```python
# En cv_importer/controllers/__init__.py
# from . import sql_injection_test  # COMENTADO - Laboratorio de pruebas
```

### Opción 2: Eliminar completamente
```bash
# Eliminar archivos
del cv_importer\controllers\sql_injection_test.py
del cv_importer\SQL_INJECTION_TEST_README.md

# Remover del __init__.py
# Eliminar la línea: from . import sql_injection_test
```

### Opción 3: Deshabilitar las rutas
Comenta las decoradores `@http.route` en el archivo `sql_injection_test.py`

## 🎓 Aprendizajes Clave

### 1. ¿Por qué el ORM es mejor?
- ✅ Escapa automáticamente todos los inputs
- ✅ Previene múltiples tipos de ataques
- ✅ Más fácil de leer y mantener
- ✅ Soporta búsquedas complejas de forma segura
- ✅ Integrado con el sistema de permisos de Odoo

### 2. ¿Cuándo usar SQL directo?
Solo cuando:
- Necesitas consultas muy complejas que el ORM no soporta
- Optimizaciones de rendimiento críticas
- **SIEMPRE con parámetros parametrizados**

### 3. Señales de código inseguro
```python
# ❌ Buscar y evitar estos patrones:
f"SELECT * FROM table WHERE field = '{user_input}'"
"SELECT * FROM table WHERE field = " + user_input
"SELECT * FROM table WHERE field = %s" % user_input
```

## 📝 Logs

Los métodos vulnerables registran en el log con nivel WARNING:
```
[WARNING] EJECUTANDO BÚSQUEDA VULNERABLE - SOLO PARA PRUEBAS
[WARNING] Input recibido: ' OR '1'='1
[WARNING] Query ejecutada: SELECT ... WHERE name ILIKE '%' OR '1'='1%'
```

Los métodos seguros usan nivel INFO:
```
[INFO] EJECUTANDO BÚSQUEDA SEGURA
[INFO] Input recibido: ' OR '1'='1
[INFO] Query segura: SELECT ... WHERE name ILIKE %s
[INFO] Parámetro: %' OR '1'='1%
```

## 🔗 Referencias

- [OWASP SQL Injection](https://owasp.org/www-community/attacks/SQL_Injection)
- [Odoo Security Guidelines](https://www.odoo.com/documentation/17.0/developer/reference/backend/security.html)
- [PostgreSQL SQL Injection Prevention](https://www.postgresql.org/docs/current/sql-prepare.html)

## ✅ Checklist Final

Antes de deployment a producción:

- [ ] Comentar o eliminar `sql_injection_test.py`
- [ ] Remover import en `controllers/__init__.py`
- [ ] Verificar que no hay `cr.execute()` con concatenación de strings
- [ ] Confirmar que todo usa ORM de Odoo
- [ ] Eliminar este README si no es necesario

---

**Recuerda:** Este código existe ÚNICAMENTE para educación y pruebas. 
Tu código productivo está SEGURO porque usa el ORM correctamente. 🎉
