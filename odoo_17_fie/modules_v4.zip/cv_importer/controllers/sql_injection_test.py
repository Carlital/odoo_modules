# -*- coding: utf-8 -*-
"""
ARCHIVO DE PRUEBA - SQL INJECTION TESTING
==========================================
ADVERTENCIA: Este archivo contiene código INTENCIONALMENTE VULNERABLE
para pruebas y demostraciones de seguridad.

NUNCA usar en producción.
ELIMINAR o COMENTAR antes de deployment.

Propósito: Demostrar vulnerabilidades de inyección SQL vs código seguro.
"""

from odoo import http
from odoo.http import request
import logging

_logger = logging.getLogger(__name__)


class SQLInjectionTestController(http.Controller):
    """
    Controlador para pruebas de inyección SQL.
    SOLO PARA AMBIENTE DE DESARROLLO/TESTING.
    """

    # ============================================================================
    # SECCIÓN VULNERABLE - PARA PRUEBAS DE INYECCIÓN SQL
    # ============================================================================
    
    @http.route('/cv_test/vulnerable_search', type='json', auth='user', methods=['POST'])
    def vulnerable_employee_search(self, search_term=''):
        """
        VULNERABLE: Concatena directamente el input del usuario en SQL.
        
        Pruebas para hacer:
        1. Búsqueda normal: "Juan"
        2. Inyección SQL: "' OR '1'='1"
        3. Inyección avanzada: "'; DROP TABLE hr_employee; --"
        
        NUNCA USAR EN PRODUCCIÓN.
        """
        _logger.warning("=" * 80)
        _logger.warning("EJECUTANDO BÚSQUEDA VULNERABLE - SOLO PARA PRUEBAS")
        _logger.warning(f"Input recibido: {search_term}")
        _logger.warning("=" * 80)
        
        try:
            # CÓDIGO VULNERABLE - Concatenación directa
            query = f"""
                SELECT id, name, work_email, job_title 
                FROM hr_employee 
                WHERE name ILIKE '%{search_term}%'
                LIMIT 10
            """
            
            _logger.warning(f"Query ejecutada: {query}")
            
            request.env.cr.execute(query)
            results = request.env.cr.dictfetchall()
            
            return {
                'success': True,
                'method': 'VULNERABLE - Concatenación directa',
                'warning': 'Este método es INSEGURO',
                'results': results,
                'query_executed': query
            }
            
        except Exception as e:
            _logger.error(f"Error en búsqueda vulnerable: {str(e)}")
            return {
                'success': False,
                'error': str(e),
                'message': 'La inyección SQL fue detectada o causó un error'
            }

    @http.route('/cv_test/vulnerable_search_v2', type='json', auth='user', methods=['POST'])
    def vulnerable_employee_by_id(self, employee_id='1'):
        """
        VULNERABLE: Usa string formatting sin validación.
        
        Pruebas:
        1. Normal: "1"
        2. Inyección: "1 OR 1=1"
        3. Union attack: "1 UNION SELECT id, login, password, 'hack' FROM res_users"
        """
        _logger.warning("=" * 80)
        _logger.warning("EJECUTANDO BÚSQUEDA POR ID VULNERABLE")
        _logger.warning(f"Input recibido: {employee_id}")
        _logger.warning("=" * 80)
        
        try:
            query = "SELECT * FROM hr_employee WHERE id = %s" % employee_id
            
            _logger.warning(f"Query ejecutada: {query}")
            
            request.env.cr.execute(query)
            results = request.env.cr.dictfetchall()
            
            return {
                'success': True,
                'method': 'VULNERABLE - String formatting',
                'results': results,
                'query_executed': query
            }
            
        except Exception as e:
            _logger.error(f"Error: {str(e)}")
            return {'success': False, 'error': str(e)}

    # ============================================================================
    # SECCIÓN SEGURA - MÉTODOS CORRECTOS
    # ============================================================================
    
    @http.route('/cv_test/secure_search', type='json', auth='user', methods=['POST'])
    def secure_employee_search(self, search_term=''):
        """
        SEGURO: Usa parámetros parametrizados.
        
        Este es el método CORRECTO para prevenir inyección SQL.
        """
        _logger.info("=" * 80)
        _logger.info("EJECUTANDO BÚSQUEDA SEGURA")
        _logger.info(f"Input recibido: {search_term}")
        _logger.info("=" * 80)
        
        try:
            # CÓDIGO SEGURO - Parámetros parametrizados
            query = """
                SELECT id, name, work_email, job_title 
                FROM hr_employee 
                WHERE name ILIKE %s
                LIMIT 10
            """
            
            # El % de ILIKE se agrega en el parámetro, no en la query
            search_pattern = f'%{search_term}%'
            
            _logger.info(f"Query segura: {query}")
            _logger.info(f"Parámetro: {search_pattern}")
            
            request.env.cr.execute(query, (search_pattern,))
            results = request.env.cr.dictfetchall()
            
            return {
                'success': True,
                'method': 'SEGURO - Parámetros parametrizados',
                'results': results,
                'query_template': query,
                'parameters': [search_pattern]
            }
            
        except Exception as e:
            _logger.error(f"Error: {str(e)}")
            return {'success': False, 'error': str(e)}

    @http.route('/cv_test/orm_search', type='json', auth='user', methods=['POST'])
    def orm_employee_search(self, search_term=''):
        """
        MÁS SEGURO: Usa el ORM de Odoo (método recomendado).
        
        Este es el enfoque que deberías usar SIEMPRE en producción.
        """
        _logger.info("=" * 80)
        _logger.info("EJECUTANDO BÚSQUEDA CON ORM")
        _logger.info(f"Input recibido: {search_term}")
        _logger.info("=" * 80)
        
        try:
            # MEJOR PRÁCTICA - Usar ORM de Odoo
            employees = request.env['hr.employee'].search([
                ('name', 'ilike', search_term)
            ], limit=10)
            
            results = [{
                'id': emp.id,
                'name': emp.name,
                'email': emp.work_email,
                'job_title': emp.job_title
            } for emp in employees]
            
            return {
                'success': True,
                'method': 'ORM - El método MÁS SEGURO',
                'results': results,
                'count': len(results)
            }
            
        except Exception as e:
            _logger.error(f"Error: {str(e)}")
            return {'success': False, 'error': str(e)}

    # ============================================================================
    # INTERFACE DE PRUEBA
    # ============================================================================
    
    @http.route('/cv_test/sql_injection_demo', type='http', auth='user')
    def sql_injection_demo_page(self):
        """
        Página HTML para probar las diferentes implementaciones.
        """
        html = """
        <!DOCTYPE html>
        <html>
        <head>
            <title>SQL Injection Testing - SOLO DESARROLLO</title>
            <style>
                body { 
                    font-family: Arial, sans-serif; 
                    max-width: 1200px; 
                    margin: 50px auto; 
                    padding: 20px;
                    background: #f5f5f5;
                }
                .warning {
                    background: #ff4444;
                    color: white;
                    padding: 20px;
                    border-radius: 5px;
                    margin-bottom: 20px;
                    font-weight: bold;
                }
                .container {
                    background: white;
                    padding: 30px;
                    border-radius: 8px;
                    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                }
                .test-section {
                    margin: 20px 0;
                    padding: 20px;
                    border: 2px solid #ddd;
                    border-radius: 5px;
                }
                .vulnerable { border-color: #ff4444; background: #fff5f5; }
                .secure { border-color: #44ff44; background: #f5fff5; }
                input[type="text"] {
                    width: 100%;
                    padding: 10px;
                    margin: 10px 0;
                    border: 1px solid #ddd;
                    border-radius: 4px;
                    font-size: 14px;
                }
                button {
                    padding: 10px 20px;
                    margin: 5px;
                    border: none;
                    border-radius: 4px;
                    cursor: pointer;
                    font-size: 14px;
                }
                .btn-danger { background: #ff4444; color: white; }
                .btn-success { background: #44ff44; color: black; }
                .btn-primary { background: #4444ff; color: white; }
                .results {
                    margin-top: 20px;
                    padding: 15px;
                    background: #f9f9f9;
                    border-radius: 4px;
                    max-height: 400px;
                    overflow-y: auto;
                }
                pre {
                    background: #282c34;
                    color: #abb2bf;
                    padding: 15px;
                    border-radius: 4px;
                    overflow-x: auto;
                }
                h2 { color: #333; margin-top: 30px; }
                h3 { color: #666; }
                .example { 
                    background: #e8f4f8; 
                    padding: 10px; 
                    margin: 10px 0;
                    border-left: 4px solid #0066cc;
                }
            </style>
        </head>
        <body>
            <div class="warning">
                ⚠️ ADVERTENCIA: Este es un entorno de PRUEBA ÚNICAMENTE ⚠️
                <br>Contiene código INTENCIONALMENTE VULNERABLE para demostraciones.
                <br>NUNCA usar en producción.
            </div>
            
            <div class="container">
                <h1>🔐 SQL Injection Testing Lab</h1>
                <p>Compara métodos vulnerables vs seguros de consultas SQL.</p>
                
                <!-- Sección Vulnerable -->
                <div class="test-section vulnerable">
                    <h2>❌ Método VULNERABLE (Concatenación Directa)</h2>
                    <p><strong>Riesgo:</strong> El input se concatena directamente en la query SQL.</p>
                    
                    <h3>Pruebas sugeridas:</h3>
                    <div class="example">
                        <strong>1. Búsqueda normal:</strong> <code>Juan</code><br>
                        <strong>2. Bypass simple:</strong> <code>' OR '1'='1</code><br>
                        <strong>3. Comentario SQL:</strong> <code>' OR '1'='1' --</code><br>
                        <strong>4. UNION attack:</strong> <code>' UNION SELECT id, login, password, null FROM res_users --</code>
                    </div>
                    
                    <input type="text" id="vulnerable_input" placeholder="Ingresa término de búsqueda...">
                    <button class="btn-danger" onclick="testVulnerable()">🔓 Probar Vulnerable</button>
                    <div class="results" id="vulnerable_results"></div>
                </div>
                
                <!-- Sección Segura con Parámetros -->
                <div class="test-section secure">
                    <h2>✅ Método SEGURO (Parámetros Parametrizados)</h2>
                    <p><strong>Protección:</strong> Los parámetros se escapan automáticamente.</p>
                    
                    <input type="text" id="secure_input" placeholder="Ingresa término de búsqueda...">
                    <button class="btn-success" onclick="testSecure()">🔒 Probar Seguro (SQL)</button>
                    <div class="results" id="secure_results"></div>
                </div>
                
                <!-- Sección ORM -->
                <div class="test-section secure">
                    <h2>✅✅ Método MÁS SEGURO (ORM de Odoo)</h2>
                    <p><strong>Mejor práctica:</strong> Usa el ORM de Odoo, nunca SQL directo.</p>
                    
                    <input type="text" id="orm_input" placeholder="Ingresa término de búsqueda...">
                    <button class="btn-primary" onclick="testORM()">🛡️ Probar ORM</button>
                    <div class="results" id="orm_results"></div>
                </div>
                
                <h2>📚 Explicación Técnica</h2>
                <h3>¿Por qué el código vulnerable es peligroso?</h3>
                <pre>
# VULNERABLE ❌
query = f"SELECT * FROM hr_employee WHERE name = '{user_input}'"
# Si user_input = "' OR '1'='1", la query se convierte en:
# SELECT * FROM hr_employee WHERE name = '' OR '1'='1'
# ¡Retorna TODOS los registros!

# SEGURO ✅
query = "SELECT * FROM hr_employee WHERE name = %s"
cr.execute(query, (user_input,))
# El parámetro se escapa automáticamente, previniendo inyección

# MÁS SEGURO ✅✅
employees = env['hr.employee'].search([('name', '=', user_input)])
# El ORM maneja toda la seguridad automáticamente
                </pre>
            </div>
            
            <script>
                function testVulnerable() {
                    const input = document.getElementById('vulnerable_input').value;
                    fetch('/cv_test/vulnerable_search', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            jsonrpc: '2.0',
                            method: 'call',
                            params: { search_term: input }
                        })
                    })
                    .then(res => res.json())
                    .then(data => {
                        document.getElementById('vulnerable_results').innerHTML = 
                            '<h4>Resultado:</h4><pre>' + JSON.stringify(data.result, null, 2) + '</pre>';
                    })
                    .catch(err => {
                        document.getElementById('vulnerable_results').innerHTML = 
                            '<h4>Error:</h4><pre>' + err.message + '</pre>';
                    });
                }
                
                function testSecure() {
                    const input = document.getElementById('secure_input').value;
                    fetch('/cv_test/secure_search', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            jsonrpc: '2.0',
                            method: 'call',
                            params: { search_term: input }
                        })
                    })
                    .then(res => res.json())
                    .then(data => {
                        document.getElementById('secure_results').innerHTML = 
                            '<h4>Resultado:</h4><pre>' + JSON.stringify(data.result, null, 2) + '</pre>';
                    });
                }
                
                function testORM() {
                    const input = document.getElementById('orm_input').value;
                    fetch('/cv_test/orm_search', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            jsonrpc: '2.0',
                            method: 'call',
                            params: { search_term: input }
                        })
                    })
                    .then(res => res.json())
                    .then(data => {
                        document.getElementById('orm_results').innerHTML = 
                            '<h4>Resultado:</h4><pre>' + JSON.stringify(data.result, null, 2) + '</pre>';
                    });
                }
            </script>
        </body>
        </html>
        """
        return html
