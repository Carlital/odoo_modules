from odoo import models, fields

class CustomPlan(models.Model):
    _name = 'crm.custom.plan'


    value_ids = fields.One2many(
        'crm.custom.plan.value',
        'plan_id',
        string='Valores'
    )
