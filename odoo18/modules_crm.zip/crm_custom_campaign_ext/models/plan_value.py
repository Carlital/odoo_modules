from odoo import models, fields

class PlanValue(models.Model):
    _name = 'crm.custom.plan.value'
    _description = 'Plan Value'

    name = fields.Char(string='Nombre')

    plan_id = fields.Many2one(
        'crm.custom.plan',
        string='Plan',
        required=True,
        ondelete='cascade',
        index=True,
    )

    section_id = fields.Many2one(
        'crm.custom.plan.section',
        string='Sección',
        index=True,
    )


    subcampaign_id = fields.Many2one(
        'crm.custom.plan',
        string='Subcampaña',
        ondelete='cascade',
        index=True,
    )