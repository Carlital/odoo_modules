from odoo import api, fields, models
from odoo import Command


class CrmCustomPlanTemplateSection(models.Model):
    _name = "crm.custom.plan.template.section"
    _description = "Seccion de Plantilla de Plan"
    _order = "template_id, sequence, id"

    name = fields.Char(required=True, string="Nombre de la seccion")
    sequence = fields.Integer(default=10)
    template_id = fields.Many2one(
        "crm.custom.plan.template", required=True, ondelete="cascade", string="Plantilla"
    )


class CrmCustomPlanTemplateAttrExt(models.Model):
    _inherit = "crm.custom.plan.template.attr"

    section_id = fields.Many2one(
        "crm.custom.plan.template.section", string="Seccion"
    )


class CrmCustomPlanExt(models.Model):
    _inherit = "crm.custom.plan"

    def action_sync_template_values(self):
        for rec in self:
            if not rec.template_id:
                continue
            try:
                existing_attr_ids = set(rec.value_ids.mapped("attribute_id").ids)
            except Exception:
                existing_attr_ids = set()
            missing_attrs = [a for a in rec.template_id.attribute_ids if a.id not in existing_attr_ids]
            if rec.id:
                for attr in missing_attrs:
                    self.env["crm.custom.plan.value"].create({
                        "plan_id": rec.id,
                        "attribute_id": attr.id,
                    })
            else:
                commands = list(getattr(rec, "value_ids", []))
                for attr in missing_attrs:
                    commands.append(Command.create({"attribute_id": attr.id}))
                rec.update({"value_ids": commands})
        return True

    @api.onchange("template_id")
    def _onchange_template_id_sync(self):
        for rec in self:
            if rec.template_id:
                rec.action_sync_template_values()


class CrmCustomPlanValueExt(models.Model):
    _inherit = "crm.custom.plan.value"

    section_id = fields.Many2one(
        related="attribute_id.section_id", store=False, string="Seccion"
    )
    unit_rel = fields.Char(related="attribute_id.unit", store=False, string="Unidad")
    value_input = fields.Char(string="Valor", compute="_compute_value_input", inverse="_inverse_value_input", store=False)

    @api.depends("attr_type", "value_char", "value_text", "value_int", "value_float", "value_bool", "value_date", "value_selection")
    def _compute_value_input(self):
        for rec in self:
            val = ""
            if rec.attr_type == "char":
                val = rec.value_char or ""
            elif rec.attr_type == "text":
                val = rec.value_text or ""
            elif rec.attr_type == "integer":
                val = rec.value_int is not None and str(rec.value_int) or ""
            elif rec.attr_type == "float":
                val = rec.value_float is not None and ("%g" % rec.value_float) or ""
            elif rec.attr_type == "boolean":
                val = "Si" if rec.value_bool else "No"
            elif rec.attr_type == "date":
                val = rec.value_date and fields.Date.to_string(rec.value_date) or ""
            elif rec.attr_type == "selection":
                val = rec.value_selection or ""
            rec.value_input = val

    def _inverse_value_input(self):
        for rec in self:
            txt = (rec.value_input or "").strip()
            rec.value_char = False
            rec.value_text = False
            rec.value_int = False
            rec.value_float = False
            rec.value_bool = False
            rec.value_date = False
            rec.value_selection = False
            if rec.attr_type == "char":
                rec.value_char = txt or False
            elif rec.attr_type == "text":
                rec.value_text = txt or False
            elif rec.attr_type == "integer":
                try:
                    rec.value_int = int(round(float(txt.replace(",", ".")))) if txt else False
                except Exception:
                    rec.value_int = False
            elif rec.attr_type == "float":
                try:
                    rec.value_float = float(txt.replace(",", ".")) if txt else False
                except Exception:
                    rec.value_float = False
            elif rec.attr_type == "boolean":
                rec.value_bool = txt.lower() in ("si", "true", "1", "y", "yes")
            elif rec.attr_type == "date":
                try:
                    rec.value_date = txt and fields.Date.from_string(txt) or False
                except Exception:
                    rec.value_date = False
            elif rec.attr_type == "selection":
                rec.value_selection = txt or False


class CrmCustomPlanTemplateExt(models.Model):
    _inherit = "crm.custom.plan.template"

    is_global = fields.Boolean(string="Global", default=False)
    section_ids = fields.One2many(
        "crm.custom.plan.template.section", "template_id", string="Secciones"
    )

    def action_generate_default_sections(self):
        Attr = self.env['crm.custom.plan.template.attr']
        Section = self.env['crm.custom.plan.template.section']
        for rec in self:
            base_names = [
                '1. Informacion general',
                '2. Beneficios y condiciones',
                '3. Paquete de datos',
                '4. Llamadas y mensajes',
                '5. Observaciones',
            ]
            name_to_sec = {s.name: s for s in rec.section_ids}
            for i, n in enumerate(base_names, start=1):
                if n not in name_to_sec:
                    name_to_sec[n] = Section.create({
                        'template_id': rec.id,
                        'name': n,
                        'sequence': i * 10,
                    })

            defs = [
                (110, 'Tarifa basica', 'tarifa_basica', 'float', 'USD', base_names[0]),
                (120, 'Tarifa basica con impuestos', 'tarifa_basica_con_impuestos', 'float', 'USD', base_names[0]),
                (130, 'Descuento por portabilidad y altas nuevas', 'descuento_portabilidad_altas', 'char', None, base_names[0]),
                (140, 'Tarifa con descuento aplicado', 'tarifa_descuento_aplicado', 'float', 'USD', base_names[0]),

                (210, 'Beneficio exclusivo Movistar', 'beneficio_exclusivo', 'char', None, base_names[1]),
                (220, 'Solo bancarizado (beneficio adicional)', 'solo_bancarizado', 'char', None, base_names[1]),
                (230, 'Vigencia de beneficio bancarizado', 'vigencia_bancarizado', 'char', None, base_names[1]),

                (310, 'Navegacion libre (GB)', 'navegacion_libre_gb', 'float', 'GB', base_names[2]),
                (320, 'Redes sociales (GB o Libre)', 'redes_sociales', 'char', None, base_names[2]),
                (330, 'Plataformas de streaming (GB o detalle de apps incluidas)', 'streaming', 'char', None, base_names[2]),
                (340, 'WhatsApp (Libre o limite)', 'whatsapp', 'char', None, base_names[2]),
                (350, 'Componente internacional (Roaming o LDI)', 'componente_internacional', 'char', None, base_names[2]),
                (360, 'Mas musica y mas video', 'mas_musica_video', 'char', None, base_names[2]),
                (370, 'Total de megas', 'total_megas', 'float', 'GB', base_names[2]),

                (410, 'Minutos a otras operadoras moviles', 'minutos_otras_operadoras', 'char', None, base_names[3]),
                (420, 'Llamadas Movistar', 'llamadas_movistar', 'char', None, base_names[3]),
                (430, 'Minutos Mundo (LDI)', 'minutos_mundo_ldi', 'char', None, base_names[3]),
                (440, 'SMS todo destino', 'sms_todo_destino', 'integer', None, base_names[3]),
                (450, 'Familia y amigos', 'familia_amigos', 'char', None, base_names[3]),

                (510, 'Comentarios adicionales', 'comentarios_adicionales', 'text', None, base_names[4]),
                (520, 'Promociones o beneficios temporales', 'promociones_temporales', 'text', None, base_names[4]),
                (530, 'Fecha de vigencia del plan', 'fecha_vigencia_plan', 'char', None, base_names[4]),
            ]

            existing_codes = set(Attr.search([('template_id', '=', rec.id)]).mapped('code') or [])
            for seq, aname, code, dtype, unit, sec_name in defs:
                if code in existing_codes:
                    continue
                section = name_to_sec.get(sec_name)
                vals = {
                    'template_id': rec.id,
                    'sequence': seq,
                    'name': aname,
                    'code': code,
                    'data_type': dtype,
                    'section_id': section.id if section else False,
                }
                if unit:
                    vals['unit'] = unit
                Attr.create(vals)
        return True
