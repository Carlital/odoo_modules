from odoo import models, fields

class PlanSection(models.Model):
    _name = 'crm.custom.plan.section'
    _description = 'Plan Section'
    
    name = fields.Char(string='Nombre', required=True)
    description = fields.Text(string='Descripción')
