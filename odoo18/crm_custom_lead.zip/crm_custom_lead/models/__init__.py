from . import crm_campaign
from . import res_parish
from . import res_parish_import_helper
from . import hr_employee_motorizado
from . import crm_lead
from . import res_users
from . import res_groups
from . import res_city_ext
