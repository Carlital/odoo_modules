from odoo import models, fields, api, _
from odoo.exceptions import AccessError


class CrmCustomCampaign(models.Model):
    _name = "crm.custom.campaign"
    _description = "Campaña CRM Personalizada"
    _order = "name"

    name = fields.Char(required=True)
    fecha_inicio = fields.Date()
    fecha_fin = fields.Date()
    descripcion = fields.Text()
    descuento = fields.Float()
    activo = fields.Boolean(default=True)

    def _has_campaign_manage_rights(self):
        return (
            self.env.user.has_group("crm_custom_lead.group_jefe_operaciones")
            or self.env.user.has_group("crm_custom_lead.group_gerente")
            or self.env.user.has_group("crm_custom_lead.group_supervisor")
        )

    def write(self, vals):
        if not (self.env.context.get("install_mode") or self.env.is_superuser()):
            if not self._has_campaign_manage_rights():
                raise AccessError(_("Solo Jefe de Operaciones, Supervisor o Gerente Comercial pueden modificar campañas."))
        return super().write(vals)

    @api.model_create_multi
    def create(self, vals_list):
        if not (self.env.context.get("install_mode") or self.env.is_superuser()):
            if not self._has_campaign_manage_rights():
                raise AccessError(_("Solo Jefe de Operaciones, Supervisor o Gerente Comercial pueden crear campañas."))
        return super().create(vals_list)

