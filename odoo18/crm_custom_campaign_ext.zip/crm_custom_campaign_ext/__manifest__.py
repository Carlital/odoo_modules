{
    "name": "CRM Custom Campaign Manager",
    "version": "1.0",
    "summary": "Extiende campañas: subcampañas y planes con atributos dinámicos",
    "author": "C2Q",
    "license": "LGPL-3",
    "depends": ["base","crm_custom_lead", "web","crm"],
    "data": [
        "security/ir.model.access.csv",
        "views/bc_campaign_views.xml",
        "views/bc_subcampaign_views.xml",
        "views/bc_plan_views.xml",
        "views/crm_lead_bc_views.xml",
        "views/bc_icon_views.xml"
    ],
    "assets": {
    "web.assets_backend": [
        "crm_custom_campaign_ext/static/src/js/bc_plan_gallery.js",
        "crm_custom_campaign_ext/static/src/js/bc_subcampaign_gallery.js",
        "crm_custom_campaign_ext/static/src/xml/bc_plan_gallery.xml",
        "crm_custom_campaign_ext/static/src/css/bc_gallery.css",
    ]
    },
    "application": False
}

