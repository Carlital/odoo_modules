/** @odoo-module **/

import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";
import { Component, useState, onWillStart } from "@odoo/owl";
import { standardFieldProps } from "@web/views/fields/standard_field_props";

/**
 * Galería comercial de una subcampaña
 * - Se monta en <field name="campaign_id" widget="bc_subcampaign_gallery"/>
 * - Muestra todos los bc.plan activos de la subcampaña actual
 * - Cada plan muestra sus bc.plan.line activos (bloques comerciales)
 */
export class BcSubcampaignGalleryField extends Component {
    static template = "bc.BcSubcampaignGalleryField";
    static props = {
        ...standardFieldProps,
    };

    setup() {
        this.orm = useService("orm");

        this.state = useState({
            loading: false,
            plans: [],
        });

        onWillStart(async () => {
            await this._loadPlansForCurrentSubcampaign();
        });
    }

    /**
     * Queremos el ID REAL de la subcampaña abierta (el registro bc.subcampaign en el form).
     * Podemos leerlo desde las props del componente.
     */
    _getCurrentSubcampaignId() {
        // En un componente OWL (Odoo 18), los datos del campo están en `this.props.record`
        const recordId = this.props.record.resId;

        // Si el registro aún no ha sido guardado, `resId` será `false`
        if (!recordId) {
            console.warn(
                "[crm_custom_campaign_ext] No pude determinar subcampaign_id en BcSubcampaignGalleryField"
            );
        }
        return recordId;
    }

    async _loadPlansForCurrentSubcampaign() {
        const subId = this._getCurrentSubcampaignId();
        if (!subId) {
            this.state.plans = [];
            return;
        }

        this.state.loading = true;
        try {
            // 1. Traer planes activos de esa subcampaña
            const plans = await this.orm.searchRead(
                "bc.plan",
                [
                    ["subcampaign_id", "=", subId],
                    ["active", "=", true],
                ],
                [
                    "name",
                    "headline",
                    "price_with_tax",
                    "currency_id",
                    "line_ids",
                    "id",
                    "sequence",
                    "active",
                ],
                { order: "sequence, id" }
            );

            // 2. Traer líneas activas (bloques comerciales)
            const allLineIds = plans.flatMap((p) => p.line_ids);
            const linesByPlan = {};
            if (allLineIds.length) {
                const lines = await this.orm.searchRead(
                    "bc.plan.line",
                    [
                        ["id", "in", allLineIds],
                        ["active", "=", true],
                    ],
                    [
                        "plan_id",
                        "sequence",
                        "titulo",
                        "detalle",
                        "tipo",       // <- usamos esto para saber qué bloque es
                        "icon_hint",  // <- por si queremos iconitos o logos
                        "id",
                    ],
                    { order: "plan_id, sequence, id" }
                );

                for (const ln of lines) {
                    const pid = Array.isArray(ln.plan_id) ? ln.plan_id[0] : ln.plan_id;
                    if (!linesByPlan[pid]) {
                        linesByPlan[pid] = [];
                    }
                    linesByPlan[pid].push(ln);
                }
            }

            // 3. Adjuntar líneas en cada plan
            for (const p of plans) {
                p.lines = linesByPlan[p.id] || [];
                let currencyDisplay = '';
                if (p.currency_id) {
                    if (Array.isArray(p.currency_id)) {
                        currencyDisplay = p.currency_id[1] || '';
                        p.currency_id = p.currency_id[0];
                    } else {
                        currencyDisplay = '';
                    }
                }
                p.currency_name = currencyDisplay;
            }

            this.state.plans = plans;

            console.log(
                "[crm_custom_campaign_ext] Gallery subcampaign plans:",
                plans
            );
        } catch (err) {
            console.error(
                "[crm_custom_campaign_ext] Error cargando planes subcampaña:",
                err
            );
        } finally {
            this.state.loading = false;
        }
    }
}

// Registrar el widget como field widget
registry
    .category("fields")
        .add("bc_subcampaign_gallery", {
            component: BcSubcampaignGalleryField,
            supportedTypes: ["many2one"],
        });


