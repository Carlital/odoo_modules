# crm_custom_campaign_ext/models/bc_models.py
from datetime import date
from odoo import api, fields, models, _
from odoo.exceptions import AccessError
import base64


class BcCampaign(models.Model):
    _name = "bc.campaign"
    _description = "Campaña Comercial (BC)"
    _order = "date_start desc, name"

    name = fields.Char(required=True)
    date_start = fields.Date(required=True)
    date_end = fields.Date(required=True)
    active = fields.Boolean(default=True)

    subcampaign_ids = fields.One2many(
        "bc.subcampaign",
        "campaign_id",
        string="Subcampañas",
    )

    # ---- security helpers ----
    def _has_manage_rights(self):
        user = self.env.user
        return (
            user.has_group("base.group_system")
            or user.has_group("crm_custom_lead.group_jefe_operaciones")
        )

    def write(self, vals):
        if not (self.env.context.get("install_mode") or self.env.is_superuser()):
            if not self._has_manage_rights():
                raise AccessError(
                    _("Solo Administrador y Jefe de Operaciones pueden modificar campañas.")
                )
        return super().write(vals)

    @api.model_create_multi
    def create(self, vals_list):
        if not (self.env.context.get("install_mode") or self.env.is_superuser()):
            if not (
                self.env.user.has_group("base.group_system")
                or self.env.user.has_group("crm_custom_lead.group_jefe_operaciones")
            ):
                raise AccessError(
                    _("Solo Administrador y Jefe de Operaciones pueden crear campañas.")
                )
        return super().create(vals_list)

    def unlink(self):
        if not (self.env.context.get("install_mode") or self.env.is_superuser()):
            if not self._has_manage_rights():
                raise AccessError(
                    _("Solo Administrador y Jefe de Operaciones pueden eliminar campañas.")
                )
        return super().unlink()

    @api.model
    def get_current_campaign(self):
        """Devuelve la campaña vigente hoy (activa y dentro del rango de fechas)."""
        today = date.today()
        return self.search(
            [
                ("active", "=", True),
                ("date_start", "<=", today),
                ("date_end", ">=", today),
            ],
            limit=1,
        )


class BcSubcampaign(models.Model):
    _name = "bc.subcampaign"
    _description = "Subcampaña Comercial (BC)"
    _order = "campaign_id, name"

    name = fields.Char(required=True)
    campaign_id = fields.Many2one(
        "bc.campaign",
        required=True,
        ondelete="cascade",
        string="Campaña",
    )
    note = fields.Text(string="Nota")
    active = fields.Boolean(default=True)

    plan_ids = fields.One2many(
        "bc.plan",
        "subcampaign_id",
        string="Planes",
    )

    # Agregado: HTML computed para la vista comercial (tarjetas con miniaturas)
    bc_gallery_html = fields.Html(
        string="Vista comercial (HTML)",
        compute="_compute_bc_gallery_html",
        sanitize=False,
        readonly=True,
    )

    # DEBUG: lista de nombres de iconos detectados en la subcampaña (útil para diagnosticar)
    bc_gallery_debug_names = fields.Char(
        string='Debug: Iconos detectados',
        compute='_compute_bc_gallery_debug_names',
        read_only=True,
    )

    @api.depends(
        "plan_ids",
        "plan_ids.active",
        "plan_ids.line_ids",
        "plan_ids.line_ids.titulo",
        "plan_ids.line_ids.icon_ids",
        "plan_ids.line_ids.icon_ids.image_128",
        "plan_ids.line_ids.icon_ids.image",
    )
    def _compute_bc_gallery_html(self):
        def looks_like_b64(s):
            try:
                if not s or not isinstance(s, str):
                    return False
                # caracteres válidos base64 y padding '='
                import re
                if not re.fullmatch(r"[A-Za-z0-9+/=\n\r]+", s):
                    return False
                # longitud múltiplo de 4 mejora la heurística
                return (len(s.replace("\n", "").replace("\r", "")) % 4) == 0
            except Exception:
                return False

        def to_b64(img):
            if not img:
                return None
            # Si ya es str y parece base64, úsala tal cual
            if isinstance(img, str):
                return img if looks_like_b64(img) else None
            # memoryview/bytes/bytearray -> si es texto base64, decodificar; si no, codificar
            try:
                if isinstance(img, (bytes, bytearray, memoryview)):
                    try:
                        txt = bytes(img).decode("utf-8")
                        return txt if looks_like_b64(txt) else base64.b64encode(bytes(img)).decode()
                    except Exception:
                        return base64.b64encode(bytes(img)).decode()
                # cualquier otro tipo: convertir a bytes y codificar
                b = bytes(img)
                return base64.b64encode(b).decode()
            except Exception:
                return None

        for rec in self:
            parts = []
            plans = rec.plan_ids.filtered(lambda p: p.active)
            for plan in plans:
                # recolectar bloques de líneas, incluyendo iconos de cada línea dentro de su propio cuadro
                lines_html = []
                for ln in plan.line_ids:
                    # texto del bloque (título + detalle)
                    text = ln.titulo or ""
                    if ln.detalle:
                        text = f"{text}<div style='font-size:11px;color:#bdbdbd'>{ln.detalle}</div>"

                    # iconos asociados a ESTA línea (ln.icon_ids)
                    icon_imgs = []
                    for icon in ln.icon_ids:
                        img_data = icon.image_128 or icon.image
                        # Normalizar posibles strings con prefijo b'...'
                        if isinstance(img_data, str) and img_data.startswith("b'") and img_data.endswith("'"):
                            try:
                                img_data = img_data[2:-1]
                            except Exception:
                                pass
                        b64 = to_b64(img_data)
                        mimetype = (icon.mimetype or "").strip() or "image/png"
                        if b64 and isinstance(b64, str) and len(b64) > 16:
                            src = f"data:{mimetype};base64,{b64}"
                            icon_imgs.append(
                                f"<img src='{src}' style='height:20px;margin-left:6px;vertical-align:middle;border-radius:3px' alt='{(icon.name or '')}'/>"
                            )
                        # si no hay binario válido, no añadimos nada
                    icons_inline = ""
                    if icon_imgs:
                        icons_inline = f"<div style='margin-top:6px'>{''.join(icon_imgs)}</div>"

                    # ensamblar el bloque de la línea incluyendo sus iconos dentro del mismo cuadro
                    lines_html.append(
                        f"<div style='margin-bottom:6px;padding:8px;background:rgba(0,0,0,0.12);border-radius:4px;color:#fff'>"
                        f"{text}"
                        f"{icons_inline}"
                        f"</div>"
                    )

                # precio con moneda (si existe)
                price_html = ""
                try:
                    if plan.price_with_tax:
                        currency = plan.currency_id and plan.currency_id.symbol or ""
                        price_html = f"<div style='font-weight:700;color:#fff;margin-top:8px'>USD{plan.price_with_tax} {currency} Incl. IVA</div>"
                except Exception:
                    price_html = ""

                # card HTML (estilos simples en línea)
                card = f"""
                <div style='background:#263238;color:#fff;border-radius:8px;padding:14px;width:300px;margin:8px;display:inline-block;vertical-align:top;box-shadow:0 8px 16px rgba(0,0,0,0.25)'>
                    <div style='font-size:14px;font-weight:700;text-transform:uppercase;margin-bottom:8px'>{plan.name}</div>
                    <div style='color:#bdbdbd;font-size:12px;margin-bottom:8px'>{plan.headline or ''}</div>
                    <div style='margin-bottom:8px'>{''.join(lines_html)}</div>
                    {price_html}
                </div>
                """
                parts.append(card)
            rec.bc_gallery_html = "<div style='display:flex;flex-wrap:wrap;gap:8px'>" + "".join(parts) + "</div>"

    @api.depends('plan_ids', 'plan_ids.line_ids.icon_ids')
    def _compute_bc_gallery_debug_names(self):
        for rec in self:
            names = rec.plan_ids.mapped('line_ids.icon_ids.name')
            rec.bc_gallery_debug_names = ', '.join(filter(None, map(str, names))) or ''


class BcPlan(models.Model):
    _name = "bc.plan"
    _description = "Plan Comercial (BC)"
    _order = "subcampaign_id, sequence, name"

    name = fields.Char(required=True)
    subcampaign_id = fields.Many2one(
        "bc.subcampaign",
        required=True,
        ondelete="cascade",
        string="Subcampaña",
    )
    sequence = fields.Integer(default=10)

    price_no_tax = fields.Monetary(string="Precio sin IVA")
    price_with_tax = fields.Monetary(string="Precio con IVA")
    currency_id = fields.Many2one(
        "res.currency",
        required=True,
        default=lambda self: self.env.company.currency_id.id,
    )

    headline = fields.Char(string="Resumen")

    line_ids = fields.One2many(
        "bc.plan.line",
        "plan_id",
        string="Bloques",
        copy=True,
    )

    active = fields.Boolean(default=True)


class BcPlanLine(models.Model):
    _name = "bc.plan.line"
    _description = "Bloque del Plan Comercial (BC)"
    _order = "plan_id, sequence, id"

    plan_id = fields.Many2one(
        "bc.plan",
        required=True,
        ondelete="cascade",
        string="Plan",
    )
    sequence = fields.Integer(default=10)

    titulo = fields.Char(required=True, string="Título")
    detalle = fields.Char(string="Detalle")

    tipo = fields.Selection(
        [
            ("gb", "GB/Datos"),
            ("min", "Minutos"),
            ("roaming", "Roaming"),
            ("beneficio", "Beneficio"),
            ("precio", "Precio"),
            ("otro", "Otro"),
        ],
        default="otro",
        string="Tipo",
    )

    # --- Campos añadidos para que coincida con las vistas ---
    icon_hint = fields.Char(string="Icon Hint / Pista")
    icon_ids = fields.Many2many(
        "bc.icon",
        "bc_plan_line_icon_rel",
        "line_id",
        "icon_id",
        string="Iconos",
    )
    mimetype = fields.Char(string="MIME Type")
    active = fields.Boolean(default=True)
    # -------------------------------------------------------


class BcIcon(models.Model):
    _name = 'bc.icon'
    _description = 'Icono / recurso multimedia para líneas de plan'
    _order = 'sequence, name'

    sequence = fields.Integer(string='Sequence', default=10)
    name = fields.Char(string='Nombre', required=True)
    image = fields.Binary(string='Imagen/Icono')
    image_128 = fields.Binary(string='Imagen 128')
    mimetype = fields.Char(string='MIME Type')
    active = fields.Boolean(string='Active', default=True)


class CrmLead(models.Model):
    _inherit = 'crm.lead'

    # Campo HTML computado con <img> para mostrar miniaturas de los iconos del plan.
    bc_plan_icons_html = fields.Html(
        string='Iconos del Plan (vista)',
        compute='_compute_bc_plan_icons_html',
        sanitize=False,
        readonly=True,
    )

    # Campo Many2many compat (computado, no almacenado) para vistas/widgets que esperan m2m
    bc_plan_icon_ids = fields.Many2many(
        'bc.icon',
        'crm_lead_bc_icon_rel',
        'lead_id',
        'icon_id',
        string='Iconos del Plan (compat)',
        compute='_compute_bc_plan_icon_ids',
        store=False,
        readonly=True,
    )

    # DEBUG: lista de nombres de iconos detectados para el plan seleccionado
    bc_debug_icon_names = fields.Char(
        string='Debug: Iconos del Plan',
        compute='_compute_bc_debug_icon_names',
        read_only=True,
    )

    @api.depends('bc_plan_id', 'bc_plan_id.line_ids.icon_ids')
    def _compute_bc_plan_icon_ids(self):
        for rec in self:
            if getattr(rec, 'bc_plan_id', False):
                icon_ids = rec.bc_plan_id.line_ids.mapped('icon_ids').ids
                rec.bc_plan_icon_ids = [(6, 0, icon_ids)]
            else:
                rec.bc_plan_icon_ids = [(5,)]

    @api.depends('bc_plan_id', 'bc_plan_id.line_ids.icon_ids', 'bc_plan_id.line_ids.icon_ids.image_128', 'bc_plan_id.line_ids.icon_ids.image', 'bc_plan_id.line_ids.icon_ids.mimetype')
    def _compute_bc_plan_icons_html(self):
        def to_b64(img):
            if not img:
                return None
            if isinstance(img, str):
                return img
            try:
                b = bytes(img)
                return base64.b64encode(b).decode()
            except Exception:
                return None

        for rec in self:
            html_fragments = []
            plan = getattr(rec, 'bc_plan_id', False)
            if plan:
                icons = plan.line_ids.mapped('icon_ids')
                for icon in icons:
                    img_data = icon.image_128 or icon.image
                    if isinstance(img_data, str) and img_data.startswith("b'") and img_data.endswith("'"):
                        try:
                            img_data = img_data[2:-1]
                        except Exception:
                            pass
                    b64 = to_b64(img_data)
                    mimetype = (icon.mimetype or "").strip() or 'image/png'
                    if b64 and isinstance(b64, str) and len(b64) > 16:
                        src = f"data:{mimetype};base64,{b64}"
                        html_fragments.append(f"<img src='{src}' style='height:32px; margin-right:6px; vertical-align:middle;' alt='{(icon.name or '')}'/>")
                    else:
                        # sin binario válido mostramos el nombre como chilpa
                        html_fragments.append(f"<span style='display:inline-block; margin-right:6px; padding:2px 6px; background:#f3f3f3; border-radius:4px;'>{(icon.name or '')}</span>")
            rec.bc_plan_icons_html = "".join(html_fragments)

    @api.depends('bc_plan_id', 'bc_plan_id.line_ids.icon_ids')
    def _compute_bc_debug_icon_names(self):
        for rec in self:
            if getattr(rec, 'bc_plan_id', False):
                names = rec.bc_plan_id.line_ids.mapped('icon_ids.name')
                rec.bc_debug_icon_names = ', '.join(filter(None, map(str, names)))
            else:
                rec.bc_debug_icon_names = ''

    def _compute_bc_plan_icon_ids_alias(self):
        for rec in self:
            # Reutiliza el HTML computado para compatibilidad con vistas que refieran al alias,
            # pero no sobra ya que bc_plan_icon_ids ahora existe como m2m.
            rec.bc_plan_icon_ids = rec.bc_plan_icon_ids or []

